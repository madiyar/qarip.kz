# Bebas Neue KZ

**Bebas Neue KZ** is a Kazakh-language adaptation of Bebas Neue with extended Cyrillic character support, including additional letters required for the Kazakh language.

The original typeface was designed by Ryoichi Tsunekawa and released by Dharma Type. The author of the Kazakh character extension is unknown.

## Credits

- Original Typeface: Bebas Neue
- Original Designer: Ryoichi Tsunekawa
- Original Foundry: Dharma Type
- Kazakh Extension: Unknown
- Distribution: qarip.app

## License

This font is distributed under the SIL Open Font License, Version 1.1 (OFL-1.1).

See `OFL.txt` for the full license text.

Original typeface credits and licensing terms are retained.