-------------------------------------------------------------------------------------------------------------------------
                                                      Hiykaya
-------------------------------------------------------------------------------------------------------------------------
HIYKAYA REGULAR FONT Free for PERSONAL USE ONLY

My fonts for free use are allowed only in personal projects and for testing purposes only.
Any professional or consumer-facing projects require the purchase of a commercial license.
If the font will be transmitted or used by a client, the client must purchase an appropriate license.

Anyone who uses personal use fonts for commercial needs without buying a commercial license and without permission from the author will be subject to a fine.

More information and commercial license: qarip.kz or abayemes@gmail.com


HIYKAYA REGULAR Қарпі

Қаріпті коммерциялық мақсатта тегін қолдана аласыз. Лицензиясын сатып алмай, коммерцияға қолдануға болмайды. Рұқсатсыз я лицензиясық қаріпті коммерцияға қолдансаңыз заң арқылы айыппұл салынады.

Лицензия туралы толығырақ білу үшін qarip.kz сайтына өтіңіз. Лицензияны сатып алу үшін abayemes@gmail.com поштасына жазыңыз.

Қаріптін ең соңғы нұсқасын қаріп сайтынан, не гугл драйвтан жүктеп ала аласыз.

https://qarip.kz/
https://drive.google.com/drive/folders/1vQJro_Fyhab3xbnQg46m2ERVzHnwuksO?usp=sharing